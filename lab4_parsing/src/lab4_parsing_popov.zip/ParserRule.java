
import java.util.ArrayList;
import java.util.List;

/**
 * Author: Artem Popov <jambo@yandex-team.ru>
 * Date: 02.06.13
 */
public class ParserRule {
    final String name;
    final List<List<String>> rules;

    public ParserRule(String name) {
        this.name = name;
        this.rules = new ArrayList<List<String>>();
    }

    public void addVariant(List<String> rule) {
        rules.add(rule);
    }

    @Override
    public String toString() {
        final StringBuilder ans = new StringBuilder(name + " => ");
        for (List<String> rule : rules) {
            if (rule.isEmpty()) {
                ans.append("EPS");
            } else {
                final int size = rule.size();
                for (int j = 0; j < size; j++) {
                    ans.append(rule.get(j));
                    if (j != size - 1) ans.append(" ");
                }

            }
            ans.append(" | ");
        }
        return ans.toString();
    }
}
