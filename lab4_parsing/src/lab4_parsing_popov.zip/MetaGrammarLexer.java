// Generated from MetaGrammar.g4 by ANTLR 4.0

    import java.util.*;

import org.antlr.v4.runtime.Lexer;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.misc.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class MetaGrammarLexer extends Lexer {
	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		LEXER_RULES_PART=1, GRAMMAR_RULES_PART=2, SEMI=3, OR=4, ARROW=5, EPSILON=6, 
		NODE=7, WS=8, STRING_LITERAL=9;
	public static String[] modeNames = {
		"DEFAULT_MODE"
	};

	public static final String[] tokenNames = {
		"<INVALID>",
		"'[LEXER]'", "'[GRAMMAR]'", "';'", "'|'", "':'", "'EPS'", "NODE", "WS", 
		"STRING_LITERAL"
	};
	public static final String[] ruleNames = {
		"LEXER_RULES_PART", "GRAMMAR_RULES_PART", "SEMI", "OR", "ARROW", "EPSILON", 
		"NODE", "QUOTE", "WS", "STRING_LITERAL"
	};


	    final List<LexerRule> lexerRules = new ArrayList<LexerRule>();
	    final List<ParserRule> parserRules = new ArrayList<ParserRule>();
	    final List<String> currentVariant = new ArrayList<String>();



	public MetaGrammarLexer(CharStream input) {
		super(input);
		_interp = new LexerATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@Override
	public String getGrammarFileName() { return "MetaGrammar.g4"; }

	@Override
	public String[] getTokenNames() { return tokenNames; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String[] getModeNames() { return modeNames; }

	@Override
	public ATN getATN() { return _ATN; }

	@Override
	public void action(RuleContext _localctx, int ruleIndex, int actionIndex) {
		switch (ruleIndex) {
		case 8: WS_action((RuleContext)_localctx, actionIndex); break;
		}
	}
	private void WS_action(RuleContext _localctx, int actionIndex) {
		switch (actionIndex) {
		case 0: _channel = HIDDEN;  break;
		}
	}

	public static final String _serializedATN =
		"\2\4\13M\b\1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4"+
		"\t\t\t\4\n\t\n\4\13\t\13\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\3\3\3\3\3\3"+
		"\3\3\3\3\3\3\3\3\3\3\3\3\3\3\4\3\4\3\5\3\5\3\6\3\6\3\7\3\7\3\7\3\7\3\b"+
		"\3\b\7\b\66\n\b\f\b\16\b9\13\b\3\t\3\t\3\n\6\n>\n\n\r\n\16\n?\3\n\3\n"+
		"\3\13\3\13\3\13\3\13\6\13H\n\13\r\13\16\13I\3\13\3\13\2\f\3\3\1\5\4\1"+
		"\7\5\1\t\6\1\13\7\1\r\b\1\17\t\1\21\2\1\23\n\2\25\13\1\3\2\6\4C\\c|\7"+
		"))\62;C\\aac|\5\13\f\17\17\"\"\3))O\2\3\3\2\2\2\2\5\3\2\2\2\2\7\3\2\2"+
		"\2\2\t\3\2\2\2\2\13\3\2\2\2\2\r\3\2\2\2\2\17\3\2\2\2\2\23\3\2\2\2\2\25"+
		"\3\2\2\2\3\27\3\2\2\2\5\37\3\2\2\2\7)\3\2\2\2\t+\3\2\2\2\13-\3\2\2\2\r"+
		"/\3\2\2\2\17\63\3\2\2\2\21:\3\2\2\2\23=\3\2\2\2\25C\3\2\2\2\27\30\7]\2"+
		"\2\30\31\7N\2\2\31\32\7G\2\2\32\33\7Z\2\2\33\34\7G\2\2\34\35\7T\2\2\35"+
		"\36\7_\2\2\36\4\3\2\2\2\37 \7]\2\2 !\7I\2\2!\"\7T\2\2\"#\7C\2\2#$\7O\2"+
		"\2$%\7O\2\2%&\7C\2\2&\'\7T\2\2\'(\7_\2\2(\6\3\2\2\2)*\7=\2\2*\b\3\2\2"+
		"\2+,\7~\2\2,\n\3\2\2\2-.\7<\2\2.\f\3\2\2\2/\60\7G\2\2\60\61\7R\2\2\61"+
		"\62\7U\2\2\62\16\3\2\2\2\63\67\t\2\2\2\64\66\t\3\2\2\65\64\3\2\2\2\66"+
		"9\3\2\2\2\67\65\3\2\2\2\678\3\2\2\28\20\3\2\2\29\67\3\2\2\2:;\7)\2\2;"+
		"\22\3\2\2\2<>\t\4\2\2=<\3\2\2\2>?\3\2\2\2?=\3\2\2\2?@\3\2\2\2@A\3\2\2"+
		"\2AB\b\n\2\2B\24\3\2\2\2CG\5\21\t\2DE\7^\2\2EH\7)\2\2FH\n\5\2\2GD\3\2"+
		"\2\2GF\3\2\2\2HI\3\2\2\2IG\3\2\2\2IJ\3\2\2\2JK\3\2\2\2KL\5\21\t\2L\26"+
		"\3\2\2\2\7\2\67?GI";
	public static final ATN _ATN =
		ATNSimulator.deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
	}
}