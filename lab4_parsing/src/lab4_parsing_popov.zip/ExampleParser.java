import java.util.*;

/**
 * Author: Artem Popov <jambo@yandex-team.ru>
 * Date: 02.06.13
 */
public class ExampleParser {

    private class Node {
        List<Node> children;
        String value;

        private Node(List<Node> children) {
            this.children = children;
        }
    }

    Iterator<Lexem> lexems;
    Set<String> terminals = new HashSet<String>(Arrays.asList("or", "openBr", "closeBr", "not", "and", "xor", "var", "EPS"));
    Set<String> nonTerminals = new HashSet<String>(Arrays.asList("OR", "OR_", "XOR", "XOR_", "AND", "AND_", "TERM"));
    boolean[][] firstSet = new boolean[][] {
            {false, true, false, true, false, true, false},
            {true, false, false, false, false, false, true},
            {false, true, false, true, false, true, false},
            {false, false, false, false, false, false, true},
            {false, true, false, true, false, true, false},
            {},
            {false, true, false, true, false, true, false}
    };


//    FIRST(TERM) = (, <var>, not  | FOLLOW(TERM) = and, xor, or $, )
//    FIRST(AND') = e, and         | FOLLOW(AND') = xor, or, $, )
//    FIRST(AND) = (, <var>, not   | FOLLOW(AND) = xor, or, $, )
//    FIRST(XOR') = e, xor         | FOLLOW(XOR') = or, $, )
//    FIRST(XOR) = (, <var>, not   | FOLLOW(XOR) = or, $, )
//    FIRST(OR') = e, or           | FOLLOW(OR') = $, )
//    FIRST(OR) = (, <var>, not    | FOLLOW(OR) = $, )

    void computeFirsrSet() {



    }



}
