import java.util.List;

/**
 * Author: Artem Popov <jambo@yandex-team.ru>
 * Date: 02.06.13
 */
public class Grammar {
    final List<LexerRule> lexerRules;
    final List<ParserRule> parserRules;

    public Grammar(List<LexerRule> lexerRules, List<ParserRule> parserRules) {
        this.lexerRules = lexerRules;
        this.parserRules = parserRules;
    }
}
