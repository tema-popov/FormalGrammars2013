import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Author: Artem Popov <jambo@yandex-team.ru>
 * Date: 02.06.13
 */
public class ParserGenerator {
    private final Grammar grammar;
    Set<String> terminals;
    Set<String> nonTerminals;

    public ParserGenerator(Grammar grammar) {
        this.grammar = grammar;
    }

    boolean[][] getFirstSet() {
        //        while the firsts table has changed in the precedent loop cycle
//        for each rule
//        for each symbol in the right part of the rule
//        if symbol is terminal
//                then
//        firsts[rule.left,symbol] = true
//        leave symbol loop
//        else
//        for each terminal
//        if firsts[symbol,terminal]
//        then
//        firsts[rule.left,terminal] = true
//        if not(firsts[symbol,epsilon])
//        then
//        leave symbol loop
//        else
//        if symbol is the last of the right part of the rule
//                then
//        firsts[rule.left,epsilon] = true
        Map<String, Map<String, Boolean>> firstTable = new HashMap<String, Map<String, Boolean>>();
        for (String nonTerminal : nonTerminals) {
            firstTable.put(nonTerminal, new HashMap<String, Boolean>());
            for (String terminal : terminals) {
                firstTable.get(nonTerminal).put(terminal, false);
            }
        }
        boolean changes = true;
        while (changes) {
            for (ParserRule parserRule : grammar.parserRules) {
                for (List<String> rule : parserRule.rules) {
                    for (String s : rule) {
                        if (terminals.contains(s)) {
                            firstTable.get(s).put()

                        }
                    }
                }
            }
        }


    }
}
