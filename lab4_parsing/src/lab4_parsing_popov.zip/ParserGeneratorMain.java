import org.antlr.v4.runtime.ANTLRFileStream;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CommonTokenStream;

import java.io.IOException;

/**
 * Author: Artem Popov <jambo@yandex-team.ru>
 * Date: 02.06.13
 */
public class ParserGeneratorMain {

    public static void main(String[] args) throws IOException {
        final ParserGeneratorMain program = new ParserGeneratorMain();
        program.run();
    }

    private void run() throws IOException {
        final Grammar grammar = getGrammar();
        LexerGenerator lexerGenerator = new LexerGenerator(grammar);
        lexerGenerator.generateLexer();
    }

    private Grammar getGrammar() throws IOException {
        CharStream cs = new ANTLRFileStream("example.txt");
        final MetaGrammarLexer lexer = new MetaGrammarLexer(cs);
        final CommonTokenStream tokenStream = new CommonTokenStream(lexer);
        final MetaGrammarParser parser = new MetaGrammarParser(tokenStream);
        parser.fullGrammar();
        for (LexerRule rule : parser.lexerRules) {
            System.out.println(rule);
        }
        for (ParserRule rule : parser.parserRules) {
            System.out.println(rule);
        }
        return new Grammar(parser.lexerRules, parser.parserRules);
    }
}
