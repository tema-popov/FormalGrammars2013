// Generated from MetaGrammar.g4 by ANTLR 4.0

    import java.util.*;


import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.tree.TerminalNode;
import org.antlr.v4.runtime.tree.ErrorNode;

public class MetaGrammarBaseListener implements MetaGrammarListener {
	@Override public void enterGrammarRule(MetaGrammarParser.GrammarRuleContext ctx) { }
	@Override public void exitGrammarRule(MetaGrammarParser.GrammarRuleContext ctx) { }

	@Override public void enterString(MetaGrammarParser.StringContext ctx) { }
	@Override public void exitString(MetaGrammarParser.StringContext ctx) { }

	@Override public void enterFullGrammar(MetaGrammarParser.FullGrammarContext ctx) { }
	@Override public void exitFullGrammar(MetaGrammarParser.FullGrammarContext ctx) { }

	@Override public void enterGrammarRules(MetaGrammarParser.GrammarRulesContext ctx) { }
	@Override public void exitGrammarRules(MetaGrammarParser.GrammarRulesContext ctx) { }

	@Override public void enterLexerRules(MetaGrammarParser.LexerRulesContext ctx) { }
	@Override public void exitLexerRules(MetaGrammarParser.LexerRulesContext ctx) { }

	@Override public void enterLexerRule(MetaGrammarParser.LexerRuleContext ctx) { }
	@Override public void exitLexerRule(MetaGrammarParser.LexerRuleContext ctx) { }

	@Override public void enterSingleRule(MetaGrammarParser.SingleRuleContext ctx) { }
	@Override public void exitSingleRule(MetaGrammarParser.SingleRuleContext ctx) { }

	@Override public void enterEveryRule(ParserRuleContext ctx) { }
	@Override public void exitEveryRule(ParserRuleContext ctx) { }
	@Override public void visitTerminal(TerminalNode node) { }
	@Override public void visitErrorNode(ErrorNode node) { }
}