// Generated from MetaGrammar.g4 by ANTLR 4.0

    import java.util.*;

import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class MetaGrammarParser extends Parser {
	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		LEXER_RULES_PART=1, GRAMMAR_RULES_PART=2, SEMI=3, OR=4, ARROW=5, EPSILON=6, 
		NODE=7, WS=8, STRING_LITERAL=9;
	public static final String[] tokenNames = {
		"<INVALID>", "'[LEXER]'", "'[GRAMMAR]'", "';'", "'|'", "':'", "'EPS'", 
		"NODE", "WS", "STRING_LITERAL"
	};
	public static final int
		RULE_fullGrammar = 0, RULE_lexerRules = 1, RULE_lexerRule = 2, RULE_grammarRules = 3, 
		RULE_grammarRule = 4, RULE_singleRule = 5, RULE_string = 6;
	public static final String[] ruleNames = {
		"fullGrammar", "lexerRules", "lexerRule", "grammarRules", "grammarRule", 
		"singleRule", "string"
	};

	@Override
	public String getGrammarFileName() { return "MetaGrammar.g4"; }

	@Override
	public String[] getTokenNames() { return tokenNames; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public ATN getATN() { return _ATN; }


	    final List<LexerRule> lexerRules = new ArrayList<LexerRule>();
	    final List<ParserRule> parserRules = new ArrayList<ParserRule>();
	    final List<String> currentVariant = new ArrayList<String>();


	public MetaGrammarParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class FullGrammarContext extends ParserRuleContext {
		public TerminalNode LEXER_RULES_PART() { return getToken(MetaGrammarParser.LEXER_RULES_PART, 0); }
		public GrammarRulesContext grammarRules() {
			return getRuleContext(GrammarRulesContext.class,0);
		}
		public LexerRulesContext lexerRules() {
			return getRuleContext(LexerRulesContext.class,0);
		}
		public TerminalNode GRAMMAR_RULES_PART() { return getToken(MetaGrammarParser.GRAMMAR_RULES_PART, 0); }
		public FullGrammarContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fullGrammar; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MetaGrammarListener ) ((MetaGrammarListener)listener).enterFullGrammar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MetaGrammarListener ) ((MetaGrammarListener)listener).exitFullGrammar(this);
		}
	}

	public final FullGrammarContext fullGrammar() throws RecognitionException {
		FullGrammarContext _localctx = new FullGrammarContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_fullGrammar);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(14); match(LEXER_RULES_PART);
			setState(15); lexerRules();
			setState(16); match(GRAMMAR_RULES_PART);
			setState(17); grammarRules();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LexerRulesContext extends ParserRuleContext {
		public List<TerminalNode> SEMI() { return getTokens(MetaGrammarParser.SEMI); }
		public List<LexerRuleContext> lexerRule() {
			return getRuleContexts(LexerRuleContext.class);
		}
		public TerminalNode SEMI(int i) {
			return getToken(MetaGrammarParser.SEMI, i);
		}
		public LexerRuleContext lexerRule(int i) {
			return getRuleContext(LexerRuleContext.class,i);
		}
		public LexerRulesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lexerRules; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MetaGrammarListener ) ((MetaGrammarListener)listener).enterLexerRules(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MetaGrammarListener ) ((MetaGrammarListener)listener).exitLexerRules(this);
		}
	}

	public final LexerRulesContext lexerRules() throws RecognitionException {
		LexerRulesContext _localctx = new LexerRulesContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_lexerRules);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(24);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==NODE) {
				{
				{
				setState(19); lexerRule();
				setState(20); match(SEMI);
				}
				}
				setState(26);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LexerRuleContext extends ParserRuleContext {
		public Token NODE;
		public StringContext string;
		public TerminalNode ARROW() { return getToken(MetaGrammarParser.ARROW, 0); }
		public TerminalNode NODE() { return getToken(MetaGrammarParser.NODE, 0); }
		public StringContext string() {
			return getRuleContext(StringContext.class,0);
		}
		public LexerRuleContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lexerRule; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MetaGrammarListener ) ((MetaGrammarListener)listener).enterLexerRule(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MetaGrammarListener ) ((MetaGrammarListener)listener).exitLexerRule(this);
		}
	}

	public final LexerRuleContext lexerRule() throws RecognitionException {
		LexerRuleContext _localctx = new LexerRuleContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_lexerRule);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(27); ((LexerRuleContext)_localctx).NODE = match(NODE);
			setState(28); match(ARROW);
			setState(29); ((LexerRuleContext)_localctx).string = string();
			lexerRules.add(new LexerRule((((LexerRuleContext)_localctx).NODE!=null?((LexerRuleContext)_localctx).NODE.getText():null), (((LexerRuleContext)_localctx).string!=null?_input.getText(((LexerRuleContext)_localctx).string.start,((LexerRuleContext)_localctx).string.stop):null)));
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class GrammarRulesContext extends ParserRuleContext {
		public List<GrammarRuleContext> grammarRule() {
			return getRuleContexts(GrammarRuleContext.class);
		}
		public List<TerminalNode> SEMI() { return getTokens(MetaGrammarParser.SEMI); }
		public GrammarRuleContext grammarRule(int i) {
			return getRuleContext(GrammarRuleContext.class,i);
		}
		public TerminalNode SEMI(int i) {
			return getToken(MetaGrammarParser.SEMI, i);
		}
		public GrammarRulesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_grammarRules; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MetaGrammarListener ) ((MetaGrammarListener)listener).enterGrammarRules(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MetaGrammarListener ) ((MetaGrammarListener)listener).exitGrammarRules(this);
		}
	}

	public final GrammarRulesContext grammarRules() throws RecognitionException {
		GrammarRulesContext _localctx = new GrammarRulesContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_grammarRules);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(37);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==NODE) {
				{
				{
				setState(32); grammarRule();
				setState(33); match(SEMI);
				}
				}
				setState(39);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class GrammarRuleContext extends ParserRuleContext {
		public Token NODE;
		public SingleRuleContext singleRule(int i) {
			return getRuleContext(SingleRuleContext.class,i);
		}
		public TerminalNode ARROW() { return getToken(MetaGrammarParser.ARROW, 0); }
		public TerminalNode NODE() { return getToken(MetaGrammarParser.NODE, 0); }
		public TerminalNode OR(int i) {
			return getToken(MetaGrammarParser.OR, i);
		}
		public List<SingleRuleContext> singleRule() {
			return getRuleContexts(SingleRuleContext.class);
		}
		public List<TerminalNode> OR() { return getTokens(MetaGrammarParser.OR); }
		public GrammarRuleContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_grammarRule; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MetaGrammarListener ) ((MetaGrammarListener)listener).enterGrammarRule(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MetaGrammarListener ) ((MetaGrammarListener)listener).exitGrammarRule(this);
		}
	}

	public final GrammarRuleContext grammarRule() throws RecognitionException {
		GrammarRuleContext _localctx = new GrammarRuleContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_grammarRule);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(40); ((GrammarRuleContext)_localctx).NODE = match(NODE);

			                final ParserRule parserRule = new ParserRule((((GrammarRuleContext)_localctx).NODE!=null?((GrammarRuleContext)_localctx).NODE.getText():null));
			               
			setState(42); match(ARROW);
			setState(43); singleRule();

			                parserRule.addVariant(new ArrayList<String>(currentVariant));
			               
			setState(51);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==OR) {
				{
				{
				setState(45); match(OR);
				setState(46); singleRule();

				                parserRule.addVariant(new ArrayList<String>(currentVariant));
				               
				}
				}
				setState(53);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			parserRules.add(parserRule);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SingleRuleContext extends ParserRuleContext {
		public Token NODE;
		public TerminalNode NODE() { return getToken(MetaGrammarParser.NODE, 0); }
		public TerminalNode EPSILON() { return getToken(MetaGrammarParser.EPSILON, 0); }
		public SingleRuleContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_singleRule; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MetaGrammarListener ) ((MetaGrammarListener)listener).enterSingleRule(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MetaGrammarListener ) ((MetaGrammarListener)listener).exitSingleRule(this);
		}
	}

	public final SingleRuleContext singleRule() throws RecognitionException {
		SingleRuleContext _localctx = new SingleRuleContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_singleRule);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			currentVariant.clear();
			setState(64);
			switch (_input.LA(1)) {
			case NODE:
				{
				setState(59); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(57); ((SingleRuleContext)_localctx).NODE = match(NODE);
					currentVariant.add((((SingleRuleContext)_localctx).NODE!=null?((SingleRuleContext)_localctx).NODE.getText():null));
					}
					}
					setState(61); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==NODE );
				}
				break;
			case EPSILON:
				{
				setState(63); match(EPSILON);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringContext extends ParserRuleContext {
		public TerminalNode STRING_LITERAL() { return getToken(MetaGrammarParser.STRING_LITERAL, 0); }
		public StringContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_string; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MetaGrammarListener ) ((MetaGrammarListener)listener).enterString(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MetaGrammarListener ) ((MetaGrammarListener)listener).exitString(this);
		}
	}

	public final StringContext string() throws RecognitionException {
		StringContext _localctx = new StringContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_string);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(66); match(STRING_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\2\3\13G\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\3\2\3"+
		"\2\3\2\3\2\3\2\3\3\3\3\3\3\7\3\31\n\3\f\3\16\3\34\13\3\3\4\3\4\3\4\3\4"+
		"\3\4\3\5\3\5\3\5\7\5&\n\5\f\5\16\5)\13\5\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3"+
		"\6\3\6\7\6\64\n\6\f\6\16\6\67\13\6\3\6\3\6\3\7\3\7\3\7\6\7>\n\7\r\7\16"+
		"\7?\3\7\5\7C\n\7\3\b\3\b\3\b\2\t\2\4\6\b\n\f\16\2\2D\2\20\3\2\2\2\4\32"+
		"\3\2\2\2\6\35\3\2\2\2\b\'\3\2\2\2\n*\3\2\2\2\f:\3\2\2\2\16D\3\2\2\2\20"+
		"\21\7\3\2\2\21\22\5\4\3\2\22\23\7\4\2\2\23\24\5\b\5\2\24\3\3\2\2\2\25"+
		"\26\5\6\4\2\26\27\7\5\2\2\27\31\3\2\2\2\30\25\3\2\2\2\31\34\3\2\2\2\32"+
		"\30\3\2\2\2\32\33\3\2\2\2\33\5\3\2\2\2\34\32\3\2\2\2\35\36\7\t\2\2\36"+
		"\37\7\7\2\2\37 \5\16\b\2 !\b\4\1\2!\7\3\2\2\2\"#\5\n\6\2#$\7\5\2\2$&\3"+
		"\2\2\2%\"\3\2\2\2&)\3\2\2\2\'%\3\2\2\2\'(\3\2\2\2(\t\3\2\2\2)\'\3\2\2"+
		"\2*+\7\t\2\2+,\b\6\1\2,-\7\7\2\2-.\5\f\7\2.\65\b\6\1\2/\60\7\6\2\2\60"+
		"\61\5\f\7\2\61\62\b\6\1\2\62\64\3\2\2\2\63/\3\2\2\2\64\67\3\2\2\2\65\63"+
		"\3\2\2\2\65\66\3\2\2\2\668\3\2\2\2\67\65\3\2\2\289\b\6\1\29\13\3\2\2\2"+
		":B\b\7\1\2;<\7\t\2\2<>\b\7\1\2=;\3\2\2\2>?\3\2\2\2?=\3\2\2\2?@\3\2\2\2"+
		"@C\3\2\2\2AC\7\b\2\2B=\3\2\2\2BA\3\2\2\2C\r\3\2\2\2DE\7\13\2\2E\17\3\2"+
		"\2\2\7\32\'\65?B";
	public static final ATN _ATN =
		ATNSimulator.deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
	}
}