// Generated from pascalGrammar.g4 by ANTLR 4.0

    import java.util.*;

import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class pascalGrammarParser extends Parser {
	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, READ=2, READLN=3, WRITELN=4, WRITE=5, AND=6, ARRAY=7, BEGIN=8, 
		BOOLEAN=9, CASE=10, CHAR=11, CHR=12, EXIT=13, CONST=14, DIV=15, DO=16, 
		DOWNTO=17, ELSE=18, END=19, FILE=20, FOR=21, FORWARD=22, FUNCTION=23, 
		GOTO=24, IF=25, IN=26, INTEGER=27, LABEL=28, MOD=29, NIL=30, NOT=31, OF=32, 
		OR=33, PACKED=34, PROCEDURE=35, PROGRAM=36, REAL=37, RECORD=38, REPEAT=39, 
		SET=40, THEN=41, TO=42, TYPE=43, UNTIL=44, VAR=45, WHILE=46, WITH=47, 
		UNIT=48, INTERFACE=49, USES=50, STRING=51, IMPLEMENTATION=52, PLUS=53, 
		MINUS=54, STAR=55, SLASH=56, ASSIGN=57, COMMA=58, SEMI=59, COLON=60, EQUAL=61, 
		NOT_EQUAL=62, LT=63, LE=64, GE=65, GT=66, LPAREN=67, RPAREN=68, LBRACK=69, 
		LBRACK2=70, RBRACK=71, RBRACK2=72, POINTER=73, AT=74, DOT=75, DOTDOT=76, 
		LCURLY=77, RCURLY=78, IDENT=79, QUOTE=80, NUM_INT=81, WS=82;
	public static final String[] tokenNames = {
		"<INVALID>", "''''", "'read'", "'readln'", "'writeln'", "'write'", "'and'", 
		"'array'", "'begin'", "'boolean'", "'case'", "'char'", "'chr'", "'exit'", 
		"'const'", "'div'", "'do'", "'downto'", "'else'", "'end'", "'file'", "'for'", 
		"'forward'", "'function'", "'goto'", "'if'", "'in'", "'integer'", "'label'", 
		"'mod'", "'nil'", "'not'", "'of'", "'or'", "'packed'", "'procedure'", 
		"'program'", "'real'", "'record'", "'repeat'", "'set'", "'then'", "'to'", 
		"'type'", "'until'", "'var'", "'while'", "'with'", "'unit'", "'interface'", 
		"'uses'", "'string'", "'implementation'", "'+'", "'-'", "'*'", "'/'", 
		"':='", "','", "';'", "':'", "'='", "'<>'", "'<'", "'<='", "'>='", "'>'", 
		"'('", "')'", "'['", "'(.'", "']'", "'.)'", "'^'", "'@'", "'.'", "'..'", 
		"'{'", "'}'", "IDENT", "'''", "NUM_INT", "WS"
	};
	public static final int
		RULE_allProgram = 0, RULE_programId = 1, RULE_variables = 2, RULE_variable = 3, 
		RULE_varNames = 4, RULE_varName = 5, RULE_varType = 6, RULE_programName = 7, 
		RULE_programBody = 8, RULE_statements = 9, RULE_statement = 10, RULE_readStatement = 11, 
		RULE_writeStatement = 12, RULE_compoundStatement = 13, RULE_whileStatement = 14, 
		RULE_ifStatement = 15, RULE_assignStatement = 16, RULE_emptyStatement = 17, 
		RULE_expression = 18, RULE_cmp = 19, RULE_simpleExpression = 20, RULE_term = 21, 
		RULE_signedFactor = 22, RULE_sign = 23, RULE_factor = 24, RULE_unsignedConstant = 25, 
		RULE_stringLiteral = 26, RULE_string = 27;
	public static final String[] ruleNames = {
		"allProgram", "programId", "variables", "variable", "varNames", "varName", 
		"varType", "programName", "programBody", "statements", "statement", "readStatement", 
		"writeStatement", "compoundStatement", "whileStatement", "ifStatement", 
		"assignStatement", "emptyStatement", "expression", "cmp", "simpleExpression", 
		"term", "signedFactor", "sign", "factor", "unsignedConstant", "stringLiteral", 
		"string"
	};

	@Override
	public String getGrammarFileName() { return "pascalGrammar.g4"; }

	@Override
	public String[] getTokenNames() { return tokenNames; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public ATN getATN() { return _ATN; }


	    int currentOffset = 1;
	    public StringBuilder code = new StringBuilder("void main() {\n"); 
	    private String currentVarNames, currentVarType;
	    private Map<String, String> types = new HashMap<String, String>();
	    boolean ln = false;
	    boolean inWrite = false;
	    List<String> writeIds = new ArrayList<String>(); 
	    private void append(String s) {
	        code.append(s);
	    }                  
	    private void offset(){
	        for (int i = 0; i < currentOffset; i++) {
	            code.append("\t");                                        
	        }
	    }
	    private void addVars(String currentVarNames, String currentVarType){
	        currentVarNames = currentVarNames.replaceAll(" ", "");
	        for (String s: currentVarNames.split(",")) {                                                                   
	            if (currentVarType.equals("int"))
	                types.put(s, "%d");
	            if (currentVarType.equals("char*"))
	                types.put(s, "%s");
	        }                                                                
	    }
	    
	    public String join(List<String> list, String conjunction)
	    {
	        StringBuilder sb = new StringBuilder();
	        boolean first = true;
	        for (String item : list)
	        {
	        if (first)
	            first = false;
	        else
	            sb.append(conjunction);
	        sb.append(item);
	        }
	        return sb.toString();
	    }

	public pascalGrammarParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class AllProgramContext extends ParserRuleContext {
		public ProgramIdContext programId() {
			return getRuleContext(ProgramIdContext.class,0);
		}
		public ProgramBodyContext programBody() {
			return getRuleContext(ProgramBodyContext.class,0);
		}
		public TerminalNode DOT() { return getToken(pascalGrammarParser.DOT, 0); }
		public TerminalNode END() { return getToken(pascalGrammarParser.END, 0); }
		public TerminalNode BEGIN() { return getToken(pascalGrammarParser.BEGIN, 0); }
		public VariablesContext variables() {
			return getRuleContext(VariablesContext.class,0);
		}
		public AllProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_allProgram; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterAllProgram(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitAllProgram(this);
		}
	}

	public final AllProgramContext allProgram() throws RecognitionException {
		AllProgramContext _localctx = new AllProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_allProgram);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(57);
			_la = _input.LA(1);
			if (_la==PROGRAM) {
				{
				setState(56); programId();
				}
			}

			setState(60);
			_la = _input.LA(1);
			if (_la==VAR) {
				{
				setState(59); variables();
				}
			}

			setState(62); match(BEGIN);
			setState(63); programBody();
			setState(64); match(END);
			setState(65); match(DOT);
			append("}");
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ProgramIdContext extends ParserRuleContext {
		public TerminalNode PROGRAM() { return getToken(pascalGrammarParser.PROGRAM, 0); }
		public TerminalNode SEMI() { return getToken(pascalGrammarParser.SEMI, 0); }
		public ProgramNameContext programName() {
			return getRuleContext(ProgramNameContext.class,0);
		}
		public ProgramIdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_programId; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterProgramId(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitProgramId(this);
		}
	}

	public final ProgramIdContext programId() throws RecognitionException {
		ProgramIdContext _localctx = new ProgramIdContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_programId);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(68); match(PROGRAM);
			setState(69); programName();
			setState(70); match(SEMI);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VariablesContext extends ParserRuleContext {
		public VariableContext variable(int i) {
			return getRuleContext(VariableContext.class,i);
		}
		public TerminalNode VAR() { return getToken(pascalGrammarParser.VAR, 0); }
		public List<VariableContext> variable() {
			return getRuleContexts(VariableContext.class);
		}
		public VariablesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_variables; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterVariables(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitVariables(this);
		}
	}

	public final VariablesContext variables() throws RecognitionException {
		VariablesContext _localctx = new VariablesContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_variables);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(72); match(VAR);
			setState(76);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==IDENT) {
				{
				{
				setState(73); variable();
				}
				}
				setState(78);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VariableContext extends ParserRuleContext {
		public VarNamesContext varNames;
		public TerminalNode COLON() { return getToken(pascalGrammarParser.COLON, 0); }
		public VarNamesContext varNames() {
			return getRuleContext(VarNamesContext.class,0);
		}
		public TerminalNode SEMI() { return getToken(pascalGrammarParser.SEMI, 0); }
		public VarTypeContext varType() {
			return getRuleContext(VarTypeContext.class,0);
		}
		public VariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterVariable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitVariable(this);
		}
	}

	public final VariableContext variable() throws RecognitionException {
		VariableContext _localctx = new VariableContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_variable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(79); ((VariableContext)_localctx).varNames = varNames();
			currentVarNames = (((VariableContext)_localctx).varNames!=null?_input.getText(((VariableContext)_localctx).varNames.start,((VariableContext)_localctx).varNames.stop):null);
			setState(81); match(COLON);
			setState(82); varType();
			offset(); addVars(currentVarNames, currentVarType); append(currentVarType + " " + currentVarNames + ";\n");
			setState(84); match(SEMI);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VarNamesContext extends ParserRuleContext {
		public List<VarNameContext> varName() {
			return getRuleContexts(VarNameContext.class);
		}
		public TerminalNode COMMA(int i) {
			return getToken(pascalGrammarParser.COMMA, i);
		}
		public List<TerminalNode> COMMA() { return getTokens(pascalGrammarParser.COMMA); }
		public VarNameContext varName(int i) {
			return getRuleContext(VarNameContext.class,i);
		}
		public VarNamesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_varNames; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterVarNames(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitVarNames(this);
		}
	}

	public final VarNamesContext varNames() throws RecognitionException {
		VarNamesContext _localctx = new VarNamesContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_varNames);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(86); varName();
			setState(91);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(87); match(COMMA);
				setState(88); varName();
				}
				}
				setState(93);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VarNameContext extends ParserRuleContext {
		public TerminalNode IDENT() { return getToken(pascalGrammarParser.IDENT, 0); }
		public VarNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_varName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterVarName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitVarName(this);
		}
	}

	public final VarNameContext varName() throws RecognitionException {
		VarNameContext _localctx = new VarNameContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_varName);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(94); match(IDENT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VarTypeContext extends ParserRuleContext {
		public TerminalNode INTEGER() { return getToken(pascalGrammarParser.INTEGER, 0); }
		public TerminalNode BOOLEAN() { return getToken(pascalGrammarParser.BOOLEAN, 0); }
		public TerminalNode STRING() { return getToken(pascalGrammarParser.STRING, 0); }
		public VarTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_varType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterVarType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitVarType(this);
		}
	}

	public final VarTypeContext varType() throws RecognitionException {
		VarTypeContext _localctx = new VarTypeContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_varType);
		try {
			setState(102);
			switch (_input.LA(1)) {
			case BOOLEAN:
				enterOuterAlt(_localctx, 1);
				{
				setState(96); match(BOOLEAN);
				currentVarType = "bool";
				}
				break;
			case INTEGER:
				enterOuterAlt(_localctx, 2);
				{
				setState(98); match(INTEGER);
				currentVarType = "int";
				}
				break;
			case STRING:
				enterOuterAlt(_localctx, 3);
				{
				setState(100); match(STRING);
				currentVarType = "char*";
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ProgramNameContext extends ParserRuleContext {
		public TerminalNode IDENT() { return getToken(pascalGrammarParser.IDENT, 0); }
		public ProgramNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_programName; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterProgramName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitProgramName(this);
		}
	}

	public final ProgramNameContext programName() throws RecognitionException {
		ProgramNameContext _localctx = new ProgramNameContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_programName);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(104); match(IDENT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ProgramBodyContext extends ParserRuleContext {
		public StatementsContext statements() {
			return getRuleContext(StatementsContext.class,0);
		}
		public ProgramBodyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_programBody; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterProgramBody(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitProgramBody(this);
		}
	}

	public final ProgramBodyContext programBody() throws RecognitionException {
		ProgramBodyContext _localctx = new ProgramBodyContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_programBody);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(106); statements();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatementsContext extends ParserRuleContext {
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public List<TerminalNode> SEMI() { return getTokens(pascalGrammarParser.SEMI); }
		public TerminalNode SEMI(int i) {
			return getToken(pascalGrammarParser.SEMI, i);
		}
		public StatementsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statements; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterStatements(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitStatements(this);
		}
	}

	public final StatementsContext statements() throws RecognitionException {
		StatementsContext _localctx = new StatementsContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_statements);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(108); statement();
			setState(114);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==SEMI) {
				{
				{
				setState(109); match(SEMI);
				append(";\n");
				setState(111); statement();
				}
				}
				setState(116);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			append(";\n");
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatementContext extends ParserRuleContext {
		public CompoundStatementContext compoundStatement() {
			return getRuleContext(CompoundStatementContext.class,0);
		}
		public WhileStatementContext whileStatement() {
			return getRuleContext(WhileStatementContext.class,0);
		}
		public ReadStatementContext readStatement() {
			return getRuleContext(ReadStatementContext.class,0);
		}
		public AssignStatementContext assignStatement() {
			return getRuleContext(AssignStatementContext.class,0);
		}
		public WriteStatementContext writeStatement() {
			return getRuleContext(WriteStatementContext.class,0);
		}
		public IfStatementContext ifStatement() {
			return getRuleContext(IfStatementContext.class,0);
		}
		public EmptyStatementContext emptyStatement() {
			return getRuleContext(EmptyStatementContext.class,0);
		}
		public StatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitStatement(this);
		}
	}

	public final StatementContext statement() throws RecognitionException {
		StatementContext _localctx = new StatementContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_statement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			offset();
			setState(128);
			switch ( getInterpreter().adaptivePredict(_input,6,_ctx) ) {
			case 1:
				{
				setState(120); assignStatement();
				}
				break;

			case 2:
				{
				setState(121); emptyStatement();
				}
				break;

			case 3:
				{
				setState(122); ifStatement();
				}
				break;

			case 4:
				{
				setState(123); whileStatement();
				}
				break;

			case 5:
				{
				setState(124); compoundStatement();
				}
				break;

			case 6:
				{
				setState(125); readStatement();
				}
				break;

			case 7:
				{
				setState(126); writeStatement();
				}
				break;

			case 8:
				{
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ReadStatementContext extends ParserRuleContext {
		public Token IDENT;
		public TerminalNode RPAREN() { return getToken(pascalGrammarParser.RPAREN, 0); }
		public List<TerminalNode> IDENT() { return getTokens(pascalGrammarParser.IDENT); }
		public TerminalNode COMMA(int i) {
			return getToken(pascalGrammarParser.COMMA, i);
		}
		public TerminalNode IDENT(int i) {
			return getToken(pascalGrammarParser.IDENT, i);
		}
		public List<TerminalNode> COMMA() { return getTokens(pascalGrammarParser.COMMA); }
		public TerminalNode READ() { return getToken(pascalGrammarParser.READ, 0); }
		public TerminalNode LPAREN() { return getToken(pascalGrammarParser.LPAREN, 0); }
		public TerminalNode READLN() { return getToken(pascalGrammarParser.READLN, 0); }
		public ReadStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_readStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterReadStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitReadStatement(this);
		}
	}

	public final ReadStatementContext readStatement() throws RecognitionException {
		ReadStatementContext _localctx = new ReadStatementContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_readStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(134);
			switch (_input.LA(1)) {
			case READ:
				{
				setState(130); match(READ);
				ln = false;
				}
				break;
			case READLN:
				{
				setState(132); match(READLN);
				ln = true;
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(136); match(LPAREN);

			                 append("scanf(\""); 
			setState(138); ((ReadStatementContext)_localctx).IDENT = match(IDENT);
			append(types.get((((ReadStatementContext)_localctx).IDENT!=null?((ReadStatementContext)_localctx).IDENT.getText():null))); 
			                writeIds.add("&" + (((ReadStatementContext)_localctx).IDENT!=null?((ReadStatementContext)_localctx).IDENT.getText():null));
			setState(145);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(140); match(COMMA);
				setState(141); ((ReadStatementContext)_localctx).IDENT = match(IDENT);
				append(" " + types.get((((ReadStatementContext)_localctx).IDENT!=null?((ReadStatementContext)_localctx).IDENT.getText():null)));
				                       writeIds.add("&" + (((ReadStatementContext)_localctx).IDENT!=null?((ReadStatementContext)_localctx).IDENT.getText():null));
				}
				}
				setState(147);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(148); match(RPAREN);
			if (ln) 
			                      append("\"\\n\""); 
			                  if (!writeIds.isEmpty()) 
			                      append("\", ");
			                  append(join(writeIds, ", ")); 
			                  writeIds.clear();
			                  append(")");
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class WriteStatementContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(pascalGrammarParser.RPAREN, 0); }
		public TerminalNode WRITELN() { return getToken(pascalGrammarParser.WRITELN, 0); }
		public TerminalNode WRITE() { return getToken(pascalGrammarParser.WRITE, 0); }
		public TerminalNode LPAREN() { return getToken(pascalGrammarParser.LPAREN, 0); }
		public WriteStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_writeStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterWriteStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitWriteStatement(this);
		}
	}

	public final WriteStatementContext writeStatement() throws RecognitionException {
		WriteStatementContext _localctx = new WriteStatementContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_writeStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(155);
			switch (_input.LA(1)) {
			case WRITE:
				{
				setState(151); match(WRITE);
				ln = false;
				}
				break;
			case WRITELN:
				{
				setState(153); match(WRITELN);
				ln = true;
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(157); match(LPAREN);
			inWrite = true; append("printf("); 
			setState(162);
			_la = _input.LA(1);
			if (((((_la - 31)) & ~0x3f) == 0 && ((1L << (_la - 31)) & ((1L << (NOT - 31)) | (1L << (PLUS - 31)) | (1L << (MINUS - 31)) | (1L << (LPAREN - 31)) | (1L << (IDENT - 31)) | (1L << (QUOTE - 31)) | (1L << (NUM_INT - 31)))) != 0)) {
				{
				setState(159); expression();
				if (ln) append(" + ");
				}
			}

			setState(164); match(RPAREN);
			if (ln) append("\"\\n\""); if (!writeIds.isEmpty()) append(", "); append(join(writeIds, ", ")); writeIds.clear(); inWrite = false; append(")");
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CompoundStatementContext extends ParserRuleContext {
		public StatementsContext statements() {
			return getRuleContext(StatementsContext.class,0);
		}
		public TerminalNode END() { return getToken(pascalGrammarParser.END, 0); }
		public TerminalNode BEGIN() { return getToken(pascalGrammarParser.BEGIN, 0); }
		public CompoundStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_compoundStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterCompoundStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitCompoundStatement(this);
		}
	}

	public final CompoundStatementContext compoundStatement() throws RecognitionException {
		CompoundStatementContext _localctx = new CompoundStatementContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_compoundStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(167); match(BEGIN);
			append("{ \n"); currentOffset++;
			setState(169); statements();
			setState(170); match(END);
			append("\n"); currentOffset--; offset(); append("}\n");
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class WhileStatementContext extends ParserRuleContext {
		public StatementContext statement() {
			return getRuleContext(StatementContext.class,0);
		}
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode DO() { return getToken(pascalGrammarParser.DO, 0); }
		public TerminalNode WHILE() { return getToken(pascalGrammarParser.WHILE, 0); }
		public WhileStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_whileStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterWhileStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitWhileStatement(this);
		}
	}

	public final WhileStatementContext whileStatement() throws RecognitionException {
		WhileStatementContext _localctx = new WhileStatementContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_whileStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(173); match(WHILE);
			append("while (");
			setState(175); expression();
			append(") \n");
			setState(177); match(DO);
			setState(178); statement();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IfStatementContext extends ParserRuleContext {
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public TerminalNode THEN() { return getToken(pascalGrammarParser.THEN, 0); }
		public TerminalNode ELSE() { return getToken(pascalGrammarParser.ELSE, 0); }
		public TerminalNode IF() { return getToken(pascalGrammarParser.IF, 0); }
		public IfStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ifStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterIfStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitIfStatement(this);
		}
	}

	public final IfStatementContext ifStatement() throws RecognitionException {
		IfStatementContext _localctx = new IfStatementContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_ifStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(180); match(IF);
			append("if (");
			setState(182); expression();
			setState(183); match(THEN);
			append(")\n");
			setState(185); statement();
			setState(189);
			switch ( getInterpreter().adaptivePredict(_input,11,_ctx) ) {
			case 1:
				{
				setState(186); match(ELSE);
				append("\n"); offset(); append("else\n");
				setState(188); statement();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AssignStatementContext extends ParserRuleContext {
		public Token IDENT;
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode IDENT() { return getToken(pascalGrammarParser.IDENT, 0); }
		public TerminalNode ASSIGN() { return getToken(pascalGrammarParser.ASSIGN, 0); }
		public AssignStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterAssignStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitAssignStatement(this);
		}
	}

	public final AssignStatementContext assignStatement() throws RecognitionException {
		AssignStatementContext _localctx = new AssignStatementContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_assignStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(191); ((AssignStatementContext)_localctx).IDENT = match(IDENT);
			setState(192); match(ASSIGN);
			append((((AssignStatementContext)_localctx).IDENT!=null?((AssignStatementContext)_localctx).IDENT.getText():null) + " = ");
			setState(194); expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EmptyStatementContext extends ParserRuleContext {
		public EmptyStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_emptyStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterEmptyStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitEmptyStatement(this);
		}
	}

	public final EmptyStatementContext emptyStatement() throws RecognitionException {
		EmptyStatementContext _localctx = new EmptyStatementContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_emptyStatement);
		try {
			enterOuterAlt(_localctx, 1);
			{
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionContext extends ParserRuleContext {
		public CmpContext cmp;
		public CmpContext cmp(int i) {
			return getRuleContext(CmpContext.class,i);
		}
		public SimpleExpressionContext simpleExpression(int i) {
			return getRuleContext(SimpleExpressionContext.class,i);
		}
		public List<CmpContext> cmp() {
			return getRuleContexts(CmpContext.class);
		}
		public List<TerminalNode> NOT_EQUAL() { return getTokens(pascalGrammarParser.NOT_EQUAL); }
		public TerminalNode EQUAL(int i) {
			return getToken(pascalGrammarParser.EQUAL, i);
		}
		public List<SimpleExpressionContext> simpleExpression() {
			return getRuleContexts(SimpleExpressionContext.class);
		}
		public TerminalNode NOT_EQUAL(int i) {
			return getToken(pascalGrammarParser.NOT_EQUAL, i);
		}
		public List<TerminalNode> EQUAL() { return getTokens(pascalGrammarParser.EQUAL); }
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitExpression(this);
		}
	}

	public final ExpressionContext expression() throws RecognitionException {
		ExpressionContext _localctx = new ExpressionContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(198); simpleExpression();
			setState(211);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 61)) & ~0x3f) == 0 && ((1L << (_la - 61)) & ((1L << (EQUAL - 61)) | (1L << (NOT_EQUAL - 61)) | (1L << (LT - 61)) | (1L << (LE - 61)) | (1L << (GE - 61)) | (1L << (GT - 61)))) != 0)) {
				{
				{
				setState(206);
				switch (_input.LA(1)) {
				case EQUAL:
					{
					setState(199); match(EQUAL);
					append(" == ");
					}
					break;
				case NOT_EQUAL:
					{
					setState(201); match(NOT_EQUAL);
					append(" != ");
					}
					break;
				case LT:
				case LE:
				case GE:
				case GT:
					{
					setState(203); ((ExpressionContext)_localctx).cmp = cmp();
					append(" " + (((ExpressionContext)_localctx).cmp!=null?_input.getText(((ExpressionContext)_localctx).cmp.start,((ExpressionContext)_localctx).cmp.stop):null) + " ");
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(208); simpleExpression();
				}
				}
				setState(213);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CmpContext extends ParserRuleContext {
		public TerminalNode GT() { return getToken(pascalGrammarParser.GT, 0); }
		public TerminalNode GE() { return getToken(pascalGrammarParser.GE, 0); }
		public TerminalNode LT() { return getToken(pascalGrammarParser.LT, 0); }
		public TerminalNode LE() { return getToken(pascalGrammarParser.LE, 0); }
		public CmpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cmp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterCmp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitCmp(this);
		}
	}

	public final CmpContext cmp() throws RecognitionException {
		CmpContext _localctx = new CmpContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_cmp);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(214);
			_la = _input.LA(1);
			if ( !(((((_la - 63)) & ~0x3f) == 0 && ((1L << (_la - 63)) & ((1L << (LT - 63)) | (1L << (LE - 63)) | (1L << (GE - 63)) | (1L << (GT - 63)))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SimpleExpressionContext extends ParserRuleContext {
		public SignContext sign;
		public List<SignContext> sign() {
			return getRuleContexts(SignContext.class);
		}
		public List<TermContext> term() {
			return getRuleContexts(TermContext.class);
		}
		public TerminalNode OR(int i) {
			return getToken(pascalGrammarParser.OR, i);
		}
		public SignContext sign(int i) {
			return getRuleContext(SignContext.class,i);
		}
		public TermContext term(int i) {
			return getRuleContext(TermContext.class,i);
		}
		public List<TerminalNode> OR() { return getTokens(pascalGrammarParser.OR); }
		public SimpleExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simpleExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterSimpleExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitSimpleExpression(this);
		}
	}

	public final SimpleExpressionContext simpleExpression() throws RecognitionException {
		SimpleExpressionContext _localctx = new SimpleExpressionContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_simpleExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(216); term();
			setState(227);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << OR) | (1L << PLUS) | (1L << MINUS))) != 0)) {
				{
				{
				setState(222);
				switch (_input.LA(1)) {
				case PLUS:
				case MINUS:
					{
					setState(217); ((SimpleExpressionContext)_localctx).sign = sign();
					append(" " + (((SimpleExpressionContext)_localctx).sign!=null?_input.getText(((SimpleExpressionContext)_localctx).sign.start,((SimpleExpressionContext)_localctx).sign.stop):null) + " ");
					}
					break;
				case OR:
					{
					setState(220); match(OR);
					append(" || ");
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(224); term();
				}
				}
				setState(229);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TermContext extends ParserRuleContext {
		public List<TerminalNode> SLASH() { return getTokens(pascalGrammarParser.SLASH); }
		public List<TerminalNode> STAR() { return getTokens(pascalGrammarParser.STAR); }
		public TerminalNode MOD(int i) {
			return getToken(pascalGrammarParser.MOD, i);
		}
		public List<TerminalNode> DIV() { return getTokens(pascalGrammarParser.DIV); }
		public List<TerminalNode> AND() { return getTokens(pascalGrammarParser.AND); }
		public TerminalNode SLASH(int i) {
			return getToken(pascalGrammarParser.SLASH, i);
		}
		public List<SignedFactorContext> signedFactor() {
			return getRuleContexts(SignedFactorContext.class);
		}
		public List<TerminalNode> MOD() { return getTokens(pascalGrammarParser.MOD); }
		public TerminalNode AND(int i) {
			return getToken(pascalGrammarParser.AND, i);
		}
		public TerminalNode DIV(int i) {
			return getToken(pascalGrammarParser.DIV, i);
		}
		public SignedFactorContext signedFactor(int i) {
			return getRuleContext(SignedFactorContext.class,i);
		}
		public TerminalNode STAR(int i) {
			return getToken(pascalGrammarParser.STAR, i);
		}
		public TermContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_term; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterTerm(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitTerm(this);
		}
	}

	public final TermContext term() throws RecognitionException {
		TermContext _localctx = new TermContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_term);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(230); signedFactor();
			setState(246);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << AND) | (1L << DIV) | (1L << MOD) | (1L << STAR) | (1L << SLASH))) != 0)) {
				{
				{
				setState(241);
				switch (_input.LA(1)) {
				case STAR:
					{
					setState(231); match(STAR);
					append(" * ");
					}
					break;
				case SLASH:
					{
					setState(233); match(SLASH);
					append(" / ");
					}
					break;
				case DIV:
					{
					setState(235); match(DIV);
					append(" / ");
					}
					break;
				case MOD:
					{
					setState(237); match(MOD);
					append(" % ");
					}
					break;
				case AND:
					{
					setState(239); match(AND);
					append(" && ");
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(243); signedFactor();
				}
				}
				setState(248);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SignedFactorContext extends ParserRuleContext {
		public SignContext sign;
		public SignContext sign() {
			return getRuleContext(SignContext.class,0);
		}
		public FactorContext factor() {
			return getRuleContext(FactorContext.class,0);
		}
		public SignedFactorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_signedFactor; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterSignedFactor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitSignedFactor(this);
		}
	}

	public final SignedFactorContext signedFactor() throws RecognitionException {
		SignedFactorContext _localctx = new SignedFactorContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_signedFactor);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(252);
			_la = _input.LA(1);
			if (_la==PLUS || _la==MINUS) {
				{
				setState(249); ((SignedFactorContext)_localctx).sign = sign();
				append((((SignedFactorContext)_localctx).sign!=null?_input.getText(((SignedFactorContext)_localctx).sign.start,((SignedFactorContext)_localctx).sign.stop):null));
				}
			}

			setState(254); factor();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SignContext extends ParserRuleContext {
		public TerminalNode PLUS() { return getToken(pascalGrammarParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(pascalGrammarParser.MINUS, 0); }
		public SignContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sign; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterSign(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitSign(this);
		}
	}

	public final SignContext sign() throws RecognitionException {
		SignContext _localctx = new SignContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_sign);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(256);
			_la = _input.LA(1);
			if ( !(_la==PLUS || _la==MINUS) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FactorContext extends ParserRuleContext {
		public Token IDENT;
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(pascalGrammarParser.RPAREN, 0); }
		public TerminalNode IDENT() { return getToken(pascalGrammarParser.IDENT, 0); }
		public UnsignedConstantContext unsignedConstant() {
			return getRuleContext(UnsignedConstantContext.class,0);
		}
		public TerminalNode NOT() { return getToken(pascalGrammarParser.NOT, 0); }
		public FactorContext factor() {
			return getRuleContext(FactorContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(pascalGrammarParser.LPAREN, 0); }
		public FactorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_factor; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterFactor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitFactor(this);
		}
	}

	public final FactorContext factor() throws RecognitionException {
		FactorContext _localctx = new FactorContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_factor);
		try {
			setState(270);
			switch (_input.LA(1)) {
			case IDENT:
				enterOuterAlt(_localctx, 1);
				{
				setState(258); ((FactorContext)_localctx).IDENT = match(IDENT);
				  
				       if (inWrite) {
				           writeIds.add((((FactorContext)_localctx).IDENT!=null?((FactorContext)_localctx).IDENT.getText():null));
				           append("\"" + types.get((((FactorContext)_localctx).IDENT!=null?((FactorContext)_localctx).IDENT.getText():null)) + "\"");
				       } else append((((FactorContext)_localctx).IDENT!=null?((FactorContext)_localctx).IDENT.getText():null));
				      
				}
				break;
			case LPAREN:
				enterOuterAlt(_localctx, 2);
				{
				setState(260); match(LPAREN);
				append("(");
				setState(262); expression();
				setState(263); match(RPAREN);
				append(")");
				}
				break;
			case QUOTE:
			case NUM_INT:
				enterOuterAlt(_localctx, 3);
				{
				setState(266); unsignedConstant();
				}
				break;
			case NOT:
				enterOuterAlt(_localctx, 4);
				{
				setState(267); match(NOT);
				append("!");
				setState(269); factor();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class UnsignedConstantContext extends ParserRuleContext {
		public Token NUM_INT;
		public StringLiteralContext stringLiteral() {
			return getRuleContext(StringLiteralContext.class,0);
		}
		public TerminalNode NUM_INT() { return getToken(pascalGrammarParser.NUM_INT, 0); }
		public UnsignedConstantContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unsignedConstant; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterUnsignedConstant(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitUnsignedConstant(this);
		}
	}

	public final UnsignedConstantContext unsignedConstant() throws RecognitionException {
		UnsignedConstantContext _localctx = new UnsignedConstantContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_unsignedConstant);
		try {
			setState(275);
			switch (_input.LA(1)) {
			case NUM_INT:
				enterOuterAlt(_localctx, 1);
				{
				setState(272); ((UnsignedConstantContext)_localctx).NUM_INT = match(NUM_INT);

				       if (inWrite) {
				           writeIds.add((((UnsignedConstantContext)_localctx).NUM_INT!=null?((UnsignedConstantContext)_localctx).NUM_INT.getText():null));
				           append("\"%d\"");
				       } else append((((UnsignedConstantContext)_localctx).NUM_INT!=null?((UnsignedConstantContext)_localctx).NUM_INT.getText():null));
				      
				}
				break;
			case QUOTE:
				enterOuterAlt(_localctx, 2);
				{
				setState(274); stringLiteral();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringLiteralContext extends ParserRuleContext {
		public StringContext string;
		public List<TerminalNode> QUOTE() { return getTokens(pascalGrammarParser.QUOTE); }
		public StringContext string() {
			return getRuleContext(StringContext.class,0);
		}
		public TerminalNode QUOTE(int i) {
			return getToken(pascalGrammarParser.QUOTE, i);
		}
		public StringLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringLiteral; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterStringLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitStringLiteral(this);
		}
	}

	public final StringLiteralContext stringLiteral() throws RecognitionException {
		StringLiteralContext _localctx = new StringLiteralContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_stringLiteral);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(277); match(QUOTE);
			setState(278); ((StringLiteralContext)_localctx).string = string();
			setState(279); match(QUOTE);
			append("\"" + (((StringLiteralContext)_localctx).string!=null?_input.getText(((StringLiteralContext)_localctx).string.start,((StringLiteralContext)_localctx).string.stop):null) + "\"");
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringContext extends ParserRuleContext {
		public StringContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_string; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).enterString(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof pascalGrammarListener ) ((pascalGrammarListener)listener).exitString(this);
		}
	}

	public final StringContext string() throws RecognitionException {
		StringContext _localctx = new StringContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_string);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(286);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 1) | (1L << READ) | (1L << READLN) | (1L << WRITELN) | (1L << WRITE) | (1L << AND) | (1L << ARRAY) | (1L << BEGIN) | (1L << BOOLEAN) | (1L << CASE) | (1L << CHAR) | (1L << CHR) | (1L << EXIT) | (1L << CONST) | (1L << DIV) | (1L << DO) | (1L << DOWNTO) | (1L << ELSE) | (1L << END) | (1L << FILE) | (1L << FOR) | (1L << FORWARD) | (1L << FUNCTION) | (1L << GOTO) | (1L << IF) | (1L << IN) | (1L << INTEGER) | (1L << LABEL) | (1L << MOD) | (1L << NIL) | (1L << NOT) | (1L << OF) | (1L << OR) | (1L << PACKED) | (1L << PROCEDURE) | (1L << PROGRAM) | (1L << REAL) | (1L << RECORD) | (1L << REPEAT) | (1L << SET) | (1L << THEN) | (1L << TO) | (1L << TYPE) | (1L << UNTIL) | (1L << VAR) | (1L << WHILE) | (1L << WITH) | (1L << UNIT) | (1L << INTERFACE) | (1L << USES) | (1L << STRING) | (1L << IMPLEMENTATION) | (1L << PLUS) | (1L << MINUS) | (1L << STAR) | (1L << SLASH) | (1L << ASSIGN) | (1L << COMMA) | (1L << SEMI) | (1L << COLON) | (1L << EQUAL) | (1L << NOT_EQUAL) | (1L << LT))) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & ((1L << (LE - 64)) | (1L << (GE - 64)) | (1L << (GT - 64)) | (1L << (LPAREN - 64)) | (1L << (RPAREN - 64)) | (1L << (LBRACK - 64)) | (1L << (LBRACK2 - 64)) | (1L << (RBRACK - 64)) | (1L << (RBRACK2 - 64)) | (1L << (POINTER - 64)) | (1L << (AT - 64)) | (1L << (DOT - 64)) | (1L << (DOTDOT - 64)) | (1L << (LCURLY - 64)) | (1L << (RCURLY - 64)) | (1L << (IDENT - 64)) | (1L << (NUM_INT - 64)) | (1L << (WS - 64)))) != 0)) {
				{
				setState(284);
				switch ( getInterpreter().adaptivePredict(_input,21,_ctx) ) {
				case 1:
					{
					setState(282); match(1);
					}
					break;

				case 2:
					{
					setState(283);
					_la = _input.LA(1);
					if ( _la <= 0 || (_la==QUOTE) ) {
					_errHandler.recoverInline(this);
					}
					consume();
					}
					break;
				}
				}
				setState(288);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\2\3T\u0124\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4"+
		"\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20"+
		"\4\21\t\21\4\22\t\22\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27"+
		"\4\30\t\30\4\31\t\31\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\3\2\5\2<"+
		"\n\2\3\2\5\2?\n\2\3\2\3\2\3\2\3\2\3\2\3\2\3\3\3\3\3\3\3\3\3\4\3\4\7\4"+
		"M\n\4\f\4\16\4P\13\4\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\6\3\6\3\6\7\6\\\n\6"+
		"\f\6\16\6_\13\6\3\7\3\7\3\b\3\b\3\b\3\b\3\b\3\b\5\bi\n\b\3\t\3\t\3\n\3"+
		"\n\3\13\3\13\3\13\3\13\7\13s\n\13\f\13\16\13v\13\13\3\13\3\13\3\f\3\f"+
		"\3\f\3\f\3\f\3\f\3\f\3\f\3\f\5\f\u0083\n\f\3\r\3\r\3\r\3\r\5\r\u0089\n"+
		"\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\7\r\u0092\n\r\f\r\16\r\u0095\13\r\3\r\3"+
		"\r\3\r\3\16\3\16\3\16\3\16\5\16\u009e\n\16\3\16\3\16\3\16\3\16\3\16\5"+
		"\16\u00a5\n\16\3\16\3\16\3\16\3\17\3\17\3\17\3\17\3\17\3\17\3\20\3\20"+
		"\3\20\3\20\3\20\3\20\3\20\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21"+
		"\5\21\u00c0\n\21\3\22\3\22\3\22\3\22\3\22\3\23\3\23\3\24\3\24\3\24\3\24"+
		"\3\24\3\24\3\24\3\24\5\24\u00d1\n\24\3\24\7\24\u00d4\n\24\f\24\16\24\u00d7"+
		"\13\24\3\25\3\25\3\26\3\26\3\26\3\26\3\26\3\26\5\26\u00e1\n\26\3\26\7"+
		"\26\u00e4\n\26\f\26\16\26\u00e7\13\26\3\27\3\27\3\27\3\27\3\27\3\27\3"+
		"\27\3\27\3\27\3\27\3\27\5\27\u00f4\n\27\3\27\7\27\u00f7\n\27\f\27\16\27"+
		"\u00fa\13\27\3\30\3\30\3\30\5\30\u00ff\n\30\3\30\3\30\3\31\3\31\3\32\3"+
		"\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\5\32\u0111\n\32"+
		"\3\33\3\33\3\33\5\33\u0116\n\33\3\34\3\34\3\34\3\34\3\34\3\35\3\35\7\35"+
		"\u011f\n\35\f\35\16\35\u0122\13\35\3\35\2\36\2\4\6\b\n\f\16\20\22\24\26"+
		"\30\32\34\36 \"$&(*,.\60\62\64\668\2\5\3AD\3\678\3RR\u012b\2;\3\2\2\2"+
		"\4F\3\2\2\2\6J\3\2\2\2\bQ\3\2\2\2\nX\3\2\2\2\f`\3\2\2\2\16h\3\2\2\2\20"+
		"j\3\2\2\2\22l\3\2\2\2\24n\3\2\2\2\26y\3\2\2\2\30\u0088\3\2\2\2\32\u009d"+
		"\3\2\2\2\34\u00a9\3\2\2\2\36\u00af\3\2\2\2 \u00b6\3\2\2\2\"\u00c1\3\2"+
		"\2\2$\u00c6\3\2\2\2&\u00c8\3\2\2\2(\u00d8\3\2\2\2*\u00da\3\2\2\2,\u00e8"+
		"\3\2\2\2.\u00fe\3\2\2\2\60\u0102\3\2\2\2\62\u0110\3\2\2\2\64\u0115\3\2"+
		"\2\2\66\u0117\3\2\2\28\u0120\3\2\2\2:<\5\4\3\2;:\3\2\2\2;<\3\2\2\2<>\3"+
		"\2\2\2=?\5\6\4\2>=\3\2\2\2>?\3\2\2\2?@\3\2\2\2@A\7\n\2\2AB\5\22\n\2BC"+
		"\7\25\2\2CD\7M\2\2DE\b\2\1\2E\3\3\2\2\2FG\7&\2\2GH\5\20\t\2HI\7=\2\2I"+
		"\5\3\2\2\2JN\7/\2\2KM\5\b\5\2LK\3\2\2\2MP\3\2\2\2NL\3\2\2\2NO\3\2\2\2"+
		"O\7\3\2\2\2PN\3\2\2\2QR\5\n\6\2RS\b\5\1\2ST\7>\2\2TU\5\16\b\2UV\b\5\1"+
		"\2VW\7=\2\2W\t\3\2\2\2X]\5\f\7\2YZ\7<\2\2Z\\\5\f\7\2[Y\3\2\2\2\\_\3\2"+
		"\2\2][\3\2\2\2]^\3\2\2\2^\13\3\2\2\2_]\3\2\2\2`a\7Q\2\2a\r\3\2\2\2bc\7"+
		"\13\2\2ci\b\b\1\2de\7\35\2\2ei\b\b\1\2fg\7\65\2\2gi\b\b\1\2hb\3\2\2\2"+
		"hd\3\2\2\2hf\3\2\2\2i\17\3\2\2\2jk\7Q\2\2k\21\3\2\2\2lm\5\24\13\2m\23"+
		"\3\2\2\2nt\5\26\f\2op\7=\2\2pq\b\13\1\2qs\5\26\f\2ro\3\2\2\2sv\3\2\2\2"+
		"tr\3\2\2\2tu\3\2\2\2uw\3\2\2\2vt\3\2\2\2wx\b\13\1\2x\25\3\2\2\2y\u0082"+
		"\b\f\1\2z\u0083\5\"\22\2{\u0083\5$\23\2|\u0083\5 \21\2}\u0083\5\36\20"+
		"\2~\u0083\5\34\17\2\177\u0083\5\30\r\2\u0080\u0083\5\32\16\2\u0081\u0083"+
		"\3\2\2\2\u0082z\3\2\2\2\u0082{\3\2\2\2\u0082|\3\2\2\2\u0082}\3\2\2\2\u0082"+
		"~\3\2\2\2\u0082\177\3\2\2\2\u0082\u0080\3\2\2\2\u0082\u0081\3\2\2\2\u0083"+
		"\27\3\2\2\2\u0084\u0085\7\4\2\2\u0085\u0089\b\r\1\2\u0086\u0087\7\5\2"+
		"\2\u0087\u0089\b\r\1\2\u0088\u0084\3\2\2\2\u0088\u0086\3\2\2\2\u0089\u008a"+
		"\3\2\2\2\u008a\u008b\7E\2\2\u008b\u008c\b\r\1\2\u008c\u008d\7Q\2\2\u008d"+
		"\u0093\b\r\1\2\u008e\u008f\7<\2\2\u008f\u0090\7Q\2\2\u0090\u0092\b\r\1"+
		"\2\u0091\u008e\3\2\2\2\u0092\u0095\3\2\2\2\u0093\u0091\3\2\2\2\u0093\u0094"+
		"\3\2\2\2\u0094\u0096\3\2\2\2\u0095\u0093\3\2\2\2\u0096\u0097\7F\2\2\u0097"+
		"\u0098\b\r\1\2\u0098\31\3\2\2\2\u0099\u009a\7\7\2\2\u009a\u009e\b\16\1"+
		"\2\u009b\u009c\7\6\2\2\u009c\u009e\b\16\1\2\u009d\u0099\3\2\2\2\u009d"+
		"\u009b\3\2\2\2\u009e\u009f\3\2\2\2\u009f\u00a0\7E\2\2\u00a0\u00a4\b\16"+
		"\1\2\u00a1\u00a2\5&\24\2\u00a2\u00a3\b\16\1\2\u00a3\u00a5\3\2\2\2\u00a4"+
		"\u00a1\3\2\2\2\u00a4\u00a5\3\2\2\2\u00a5\u00a6\3\2\2\2\u00a6\u00a7\7F"+
		"\2\2\u00a7\u00a8\b\16\1\2\u00a8\33\3\2\2\2\u00a9\u00aa\7\n\2\2\u00aa\u00ab"+
		"\b\17\1\2\u00ab\u00ac\5\24\13\2\u00ac\u00ad\7\25\2\2\u00ad\u00ae\b\17"+
		"\1\2\u00ae\35\3\2\2\2\u00af\u00b0\7\60\2\2\u00b0\u00b1\b\20\1\2\u00b1"+
		"\u00b2\5&\24\2\u00b2\u00b3\b\20\1\2\u00b3\u00b4\7\22\2\2\u00b4\u00b5\5"+
		"\26\f\2\u00b5\37\3\2\2\2\u00b6\u00b7\7\33\2\2\u00b7\u00b8\b\21\1\2\u00b8"+
		"\u00b9\5&\24\2\u00b9\u00ba\7+\2\2\u00ba\u00bb\b\21\1\2\u00bb\u00bf\5\26"+
		"\f\2\u00bc\u00bd\7\24\2\2\u00bd\u00be\b\21\1\2\u00be\u00c0\5\26\f\2\u00bf"+
		"\u00bc\3\2\2\2\u00bf\u00c0\3\2\2\2\u00c0!\3\2\2\2\u00c1\u00c2\7Q\2\2\u00c2"+
		"\u00c3\7;\2\2\u00c3\u00c4\b\22\1\2\u00c4\u00c5\5&\24\2\u00c5#\3\2\2\2"+
		"\u00c6\u00c7\3\2\2\2\u00c7%\3\2\2\2\u00c8\u00d5\5*\26\2\u00c9\u00ca\7"+
		"?\2\2\u00ca\u00d1\b\24\1\2\u00cb\u00cc\7@\2\2\u00cc\u00d1\b\24\1\2\u00cd"+
		"\u00ce\5(\25\2\u00ce\u00cf\b\24\1\2\u00cf\u00d1\3\2\2\2\u00d0\u00c9\3"+
		"\2\2\2\u00d0\u00cb\3\2\2\2\u00d0\u00cd\3\2\2\2\u00d1\u00d2\3\2\2\2\u00d2"+
		"\u00d4\5*\26\2\u00d3\u00d0\3\2\2\2\u00d4\u00d7\3\2\2\2\u00d5\u00d3\3\2"+
		"\2\2\u00d5\u00d6\3\2\2\2\u00d6\'\3\2\2\2\u00d7\u00d5\3\2\2\2\u00d8\u00d9"+
		"\t\2\2\2\u00d9)\3\2\2\2\u00da\u00e5\5,\27\2\u00db\u00dc\5\60\31\2\u00dc"+
		"\u00dd\b\26\1\2\u00dd\u00e1\3\2\2\2\u00de\u00df\7#\2\2\u00df\u00e1\b\26"+
		"\1\2\u00e0\u00db\3\2\2\2\u00e0\u00de\3\2\2\2\u00e1\u00e2\3\2\2\2\u00e2"+
		"\u00e4\5,\27\2\u00e3\u00e0\3\2\2\2\u00e4\u00e7\3\2\2\2\u00e5\u00e3\3\2"+
		"\2\2\u00e5\u00e6\3\2\2\2\u00e6+\3\2\2\2\u00e7\u00e5\3\2\2\2\u00e8\u00f8"+
		"\5.\30\2\u00e9\u00ea\79\2\2\u00ea\u00f4\b\27\1\2\u00eb\u00ec\7:\2\2\u00ec"+
		"\u00f4\b\27\1\2\u00ed\u00ee\7\21\2\2\u00ee\u00f4\b\27\1\2\u00ef\u00f0"+
		"\7\37\2\2\u00f0\u00f4\b\27\1\2\u00f1\u00f2\7\b\2\2\u00f2\u00f4\b\27\1"+
		"\2\u00f3\u00e9\3\2\2\2\u00f3\u00eb\3\2\2\2\u00f3\u00ed\3\2\2\2\u00f3\u00ef"+
		"\3\2\2\2\u00f3\u00f1\3\2\2\2\u00f4\u00f5\3\2\2\2\u00f5\u00f7\5.\30\2\u00f6"+
		"\u00f3\3\2\2\2\u00f7\u00fa\3\2\2\2\u00f8\u00f6\3\2\2\2\u00f8\u00f9\3\2"+
		"\2\2\u00f9-\3\2\2\2\u00fa\u00f8\3\2\2\2\u00fb\u00fc\5\60\31\2\u00fc\u00fd"+
		"\b\30\1\2\u00fd\u00ff\3\2\2\2\u00fe\u00fb\3\2\2\2\u00fe\u00ff\3\2\2\2"+
		"\u00ff\u0100\3\2\2\2\u0100\u0101\5\62\32\2\u0101/\3\2\2\2\u0102\u0103"+
		"\t\3\2\2\u0103\61\3\2\2\2\u0104\u0105\7Q\2\2\u0105\u0111\b\32\1\2\u0106"+
		"\u0107\7E\2\2\u0107\u0108\b\32\1\2\u0108\u0109\5&\24\2\u0109\u010a\7F"+
		"\2\2\u010a\u010b\b\32\1\2\u010b\u0111\3\2\2\2\u010c\u0111\5\64\33\2\u010d"+
		"\u010e\7!\2\2\u010e\u010f\b\32\1\2\u010f\u0111\5\62\32\2\u0110\u0104\3"+
		"\2\2\2\u0110\u0106\3\2\2\2\u0110\u010c\3\2\2\2\u0110\u010d\3\2\2\2\u0111"+
		"\63\3\2\2\2\u0112\u0113\7S\2\2\u0113\u0116\b\33\1\2\u0114\u0116\5\66\34"+
		"\2\u0115\u0112\3\2\2\2\u0115\u0114\3\2\2\2\u0116\65\3\2\2\2\u0117\u0118"+
		"\7R\2\2\u0118\u0119\58\35\2\u0119\u011a\7R\2\2\u011a\u011b\b\34\1\2\u011b"+
		"\67\3\2\2\2\u011c\u011f\7\3\2\2\u011d\u011f\n\4\2\2\u011e\u011c\3\2\2"+
		"\2\u011e\u011d\3\2\2\2\u011f\u0122\3\2\2\2\u0120\u011e\3\2\2\2\u0120\u0121"+
		"\3\2\2\2\u01219\3\2\2\2\u0122\u0120\3\2\2\2\31;>N]ht\u0082\u0088\u0093"+
		"\u009d\u00a4\u00bf\u00d0\u00d5\u00e0\u00e5\u00f3\u00f8\u00fe\u0110\u0115"+
		"\u011e\u0120";
	public static final ATN _ATN =
		ATNSimulator.deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
	}
}